package com.gbm.vo;

/**
 * Created by Sri on 9/6/2017.
 */

public class Names {
    public String name;
}
