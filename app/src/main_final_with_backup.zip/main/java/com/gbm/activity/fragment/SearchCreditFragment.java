package com.gbm.activity.fragment;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TableRow.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;

import com.gbm.activity.R;
import com.gbm.db.GBMDBUtils;
import com.gbm.vo.CreditVO;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

/**
 * Created by Sri on 9/12/2017.
 */

public class SearchCreditFragment extends Fragment {

    private static final String TAG = "SearchCreditFragment";
    private String roleSelected;
    private View searchCreditView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the dropdown_item for this fragment
        searchCreditView = inflater.inflate(R.layout.fragment_credit_search, container, false);

        Button _searchButton = (Button) searchCreditView.findViewById(R.id.btn_search);

        _searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchCredit();
            }
        });

        final Calendar myCalendar = Calendar.getInstance();

        final EditText _bookingDate = (EditText) searchCreditView.findViewById(R.id.input_bookingDate);
        //_bookingDate.setText(new SimpleDateFormat("dd/MM/yyyy").format(myCalendar.getTime()));
        _bookingDate.setOnClickListener(new View.OnClickListener() {
            DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                    myCalendar.set(Calendar.YEAR, year);
                    myCalendar.set(Calendar.MONTH, monthOfYear);
                    myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                    _bookingDate.setText(new SimpleDateFormat("dd/MM/yyyy").format(myCalendar.getTime()));
                }
            };

            @Override
            public void onClick(View v) {
                new DatePickerDialog(getContext(), date, myCalendar.get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        searchCredit();

        return searchCreditView;
    }

    private void populateCredits(List<CreditVO> credits) {
        BigDecimal totalAmount = BigDecimal.ZERO;
        BigDecimal creditAmount = BigDecimal.ZERO;
        TableLayout _creditsTblLayout = (TableLayout) searchCreditView.findViewById(R.id.tbl_credits);
        for (int i = 0; i < _creditsTblLayout.getChildCount(); i++) {
            View child = _creditsTblLayout.getChildAt(i);
            if (child instanceof TableRow) ((ViewGroup) child).removeAllViews();
        }

        Log.d(TAG, "Populating Bookings...");
        TableRow row = new TableRow(getContext());
        row.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        row.setBackgroundResource(R.drawable.cell_shape);

        /*ImageView image = new ImageView(getContext());
        image.setImageResource(R.drawable.ic_menu_edit);
        image.setPadding(5, 5, 5, 5);
        row.addView(image);*/

        TextView tv = new TextView(getContext());
        tv.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
        tv.setTextColor(getResources().getColor(R.color.primary_dark));
        tv.setPadding(5, 5, 5, 5);
        tv.setText("Booking Date");
        row.addView(tv);

        tv = new TextView(getContext());
        tv.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
        tv.setTextColor(getResources().getColor(R.color.primary_dark));
        tv.setPadding(5, 5, 5, 5);
        tv.setText("Name");
        row.addView(tv);

        tv = new TextView(getContext());
        tv.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
        tv.setTextColor(getResources().getColor(R.color.primary_dark));
        tv.setPadding(5, 5, 5, 5);
        tv.setText("Balance");
        row.addView(tv);

        _creditsTblLayout.addView(row);

        for (CreditVO credit : credits) {
            totalAmount = totalAmount.add(credit.getTotal());
            creditAmount = creditAmount.add(credit.getBalance());
            row = new TableRow(getContext());
            row.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
            row.setBackgroundResource(R.drawable.cell_shape);

            /*image = new ImageView(getContext());
            image.setTag(credit);
            image.setImageResource(R.drawable.ic_menu_edit);
            image.setPadding(5, 5, 5, 5);
            image.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle bundle=new Bundle();
                    bundle.putSerializable("credit", (CreditVO) v.getTag());
                    Fragment fragment = new ViewCreditFragment();
                    fragment.setArguments(bundle);
                    FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.content_frame, fragment);
                    fragmentTransaction.addToBackStack(null);
                    fragmentTransaction.commit();
                }
            });
            row.addView(image);*/

            tv = new TextView(getContext());
            tv.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
            tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
            tv.setTypeface(tv.getTypeface(), Typeface.BOLD_ITALIC);
            tv.setPadding(5, 5, 5, 5);
            tv.setText(credit.getBooking().getBookingDt());
            tv.setTag(credit);
            tv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle bundle=new Bundle();
                    bundle.putSerializable("credit", (CreditVO) v.getTag());
                    Fragment fragment = new ViewCreditFragment();
                    fragment.setArguments(bundle);
                    FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.content_frame, fragment);
                    fragmentTransaction.addToBackStack(null);
                    fragmentTransaction.commit();
                }
            });
            row.addView(tv);

            tv = new TextView(getContext());
            tv.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
            tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
            tv.setPadding(5, 5, 5, 5);
            tv.setText(credit.getBooking().getReceiverName());
            row.addView(tv);

            tv = new TextView(getContext());
            tv.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
            tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
            tv.setPadding(5, 5, 5, 5);
            tv.setText(String.valueOf(credit.getBalance().setScale(2)));
            row.addView(tv);

            _creditsTblLayout.addView(row);
        }
        final TextView _total = (TextView) searchCreditView.findViewById(R.id.input_total);
        final TextView _credit = (TextView) searchCreditView.findViewById(R.id.input_credit);

        _total.setText(totalAmount.setScale(2, BigDecimal.ROUND_HALF_UP).toString());
        _credit.setText(creditAmount.setScale(2, BigDecimal.ROUND_HALF_UP).toString());
    }

    public void searchCredit() {
        Log.d(TAG, "Searching Booking...");

        final EditText _bookingNo = (EditText) searchCreditView.findViewById(R.id.input_bookingNo);
        final EditText _bookingDate = (EditText) searchCreditView.findViewById(R.id.input_bookingDate);
        final EditText _receiverName = (EditText) searchCreditView.findViewById(R.id.input_receiverName);

        CreditVO credit = new CreditVO();
        credit.setBookingNo(_bookingNo.getText().toString());
        credit.setBookingDt(_bookingDate.getText().toString());
        credit.setReceiverName(_receiverName.getText().toString());

        final ProgressDialog progressDialog = new ProgressDialog(getContext(), R.style.AppTheme_Dark_Dialog);
        progressDialog.setIndeterminate(true);
        progressDialog.setMessage("Searching...");
        progressDialog.show();
        GBMDBUtils dbUtils = new GBMDBUtils(getContext());
        List<CreditVO> credits = dbUtils.getCredits(credit);

        TableLayout _creditsTblLayout = (TableLayout) searchCreditView.findViewById(R.id.tbl_credits);
        TableLayout _totalTblLayout = (TableLayout) searchCreditView.findViewById(R.id.tbl_total);
        if(credits == null || credits.isEmpty()) {
            _creditsTblLayout.setVisibility(View.INVISIBLE);
            _totalTblLayout.setVisibility(View.INVISIBLE);
            Toast.makeText(getContext(), "No data found", Toast.LENGTH_LONG).show();
            progressDialog.dismiss();
        }
        else {
            _creditsTblLayout.setVisibility(View.VISIBLE);
            _totalTblLayout.setVisibility(View.VISIBLE);
            populateCredits(credits);
            progressDialog.dismiss();
        }

    }
}

