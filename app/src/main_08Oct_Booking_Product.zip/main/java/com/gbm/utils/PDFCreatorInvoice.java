package com.gbm.utils;

import java.math.BigDecimal;
import java.util.regex.Pattern;

import com.gbm.vo.InvoiceVO;
import com.gbm.vo.ProductVO;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;

public class PDFCreatorInvoice extends AbstractPDFCreator {

	@Override
	public <T> PdfPTable generatePDFContent(T t) {

		InvoiceVO invoice = (InvoiceVO) t;

		PdfPTable main = new PdfPTable(1);
		main.setWidthPercentage(100);

		PdfPTable detail = new PdfPTable(4);
		detail.setWidthPercentage(100);

		PdfPCell cell;
		
		cell = new PdfPCell(new Phrase("GSTIN: 33AAAFG1953A1Z5"));
		cell.setColspan(2);
		cell.setBorder(Rectangle.NO_BORDER);
		detail.addCell(cell);

		cell = new PdfPCell(new Phrase("Cell: 9597703209 / 9677790437"));
		cell.setColspan(2);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		detail.addCell(cell);

		cell = new PdfPCell(new Phrase("GEMINI BLUE METAL WORKS", new Font(FontFamily.HELVETICA, 25, Font.BOLD)));
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setColspan(4);
		cell.setPadding(5f);
		cell.setBorder(Rectangle.NO_BORDER);
		detail.addCell(cell);

		cell = new PdfPCell(new Phrase("73/3, Veppamara Salai, Alangayam Road, Vaniyambadi - 635752. Vellore Dt",
				new Font(FontFamily.HELVETICA, 9)));
		cell.setColspan(4);
		cell.setPadding(5f);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		detail.addCell(cell);
		
		main.addCell(new PdfPCell(detail));
		
		detail = new PdfPTable(3);
		detail.setWidthPercentage(100);
				
		cell = new PdfPCell(new Phrase("Invoice No.: " + invoice.getInvoiceNo(), new Font(FontFamily.HELVETICA, 12, Font.BOLD)));
		cell.setPaddingLeft(5f);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase("TAX INVOICE", new Font(FontFamily.HELVETICA, 15, Font.BOLD)));
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		detail.addCell(cell);
		
		PdfPTable info = new PdfPTable(new float[]{ 1f, 9f });
		info.setWidthPercentage(100f);
		
		cell = new PdfPCell(new Phrase("1"));
		info.addCell(cell);
		
		cell = new PdfPCell(new Phrase("Original for Receipient"));
		info.addCell(cell);
		
		cell = new PdfPCell(new Phrase("2"));
		info.addCell(cell);
		
		cell = new PdfPCell(new Phrase("Duplicate for Transporter"));
		info.addCell(cell);
		
		cell = new PdfPCell(new Phrase("3"));
		info.addCell(cell);
		
		cell = new PdfPCell(new Phrase("Triplicate for Supplier"));
		info.addCell(cell);
		
		cell = new PdfPCell(info);
		detail.addCell(cell);
		
		main.addCell(new PdfPCell(detail));
		
		detail = new PdfPTable(new float[]{ 2f, 3f, 2f, 3f });
		detail.setWidthPercentage(100);
		
		cell = new PdfPCell(new Phrase("Reverse Charge: "));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase("No.  "));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase("Date of Supply: "));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase(invoice.getInvoiceDt()));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase("Invoice Date: "));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase(invoice.getInvoiceDt()));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase("Vehicle Number: "));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase(invoice.getVehicleNo()));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase("State and Code: "));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase("Tamilnadu - 33"));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase("Place of Supply: "));
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase("Tamilnadu - 33"));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		main.addCell(new PdfPCell(detail));
		
		cell = new PdfPCell(new Phrase("Details of Receiver / Buyer", new Font(FontFamily.HELVETICA, 12, Font.BOLD)));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setPadding(5f);
		main.addCell(cell);
		
		detail = new PdfPTable(new float[]{ 2f, 3f, 2f, 3f });
		detail.setWidthPercentage(100);
		
		cell = new PdfPCell(new Phrase("Name: "));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase(invoice.getReceiverName()));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase("Aadhar: "));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase(invoice.getAadhar()));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase("Address: "));
		cell.setVerticalAlignment(Element.ALIGN_TOP);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase(invoice.getAddress()));
		cell.setVerticalAlignment(Element.ALIGN_TOP);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase("PAN: "));
		cell.setVerticalAlignment(Element.ALIGN_TOP);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase(invoice.getPan()));
		cell.setVerticalAlignment(Element.ALIGN_TOP);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase("Phone: "));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase(invoice.getPhone()));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase("GSTIN: "));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase(invoice.getGstin()));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase("State: "));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase("Tamilnadu"));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase("State Code: "));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase("33"));
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		main.addCell(new PdfPCell(detail));
		
		detail = new PdfPTable(new float[]{ 1f, 3f, 1f, 1f, 2f, 2f });
		detail.setWidthPercentage(100);
		
		cell = new PdfPCell(new Phrase("Sr. No.", new Font(FontFamily.HELVETICA, 12, Font.BOLD)));
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase("Name of Product / Commodity", new Font(FontFamily.HELVETICA, 12, Font.BOLD)));
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase("HSN / Code", new Font(FontFamily.HELVETICA, 12, Font.BOLD)));
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase("Qty", new Font(FontFamily.HELVETICA, 12, Font.BOLD)));
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase("Rate", new Font(FontFamily.HELVETICA, 12, Font.BOLD)));
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase("Taxable Value", new Font(FontFamily.HELVETICA, 12, Font.BOLD)));
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		int counter = 0;
		for(ProductVO product : invoice.getProducts()) {
			counter = counter + 1;
			
			cell = new PdfPCell(new Phrase(String.valueOf(counter)));
			cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setPadding(5f);
			detail.addCell(cell);
			
			cell = new PdfPCell(new Phrase(product.getName()));
			cell.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setPadding(5f);
			detail.addCell(cell);
			
			cell = new PdfPCell(new Phrase(product.getHsnCode()));
			cell.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setPadding(5f);
			detail.addCell(cell);
			
			cell = new PdfPCell(new Phrase(product.getQuantity().setScale(2).toString()));
			cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setPadding(5f);
			detail.addCell(cell);
			
			cell = new PdfPCell(new Phrase(product.getPrice().setScale(2).toString()));
			cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setPadding(5f);
			detail.addCell(cell);
						
			cell = new PdfPCell(new Phrase(product.getTotal().setScale(2).toString()));
			cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
			cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell.setPadding(5f);
			detail.addCell(cell);
		}
		
		String[] totalAfterTax = invoice.getTotalAfterTax().toString().split(Pattern.quote("."));
		
		Phrase inWords = new Phrase();
		inWords.add(new Chunk("Total Invoice Amount in Words:  \n\n", new Font(FontFamily.HELVETICA, 12, Font.BOLD)));
		inWords.add(new Chunk(NumberToWord.convert(totalAfterTax[0]) + " Only "));
		
		cell = new PdfPCell(inWords);
		cell.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell.setVerticalAlignment(Element.ALIGN_TOP);
		cell.setPadding(5f);
		cell.setColspan(3);
		cell.setRowspan(4);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase("Total Amount Before Tax", new Font(FontFamily.HELVETICA, 12, Font.BOLD) ));
		cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setPadding(5f);
		cell.setColspan(2);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase(invoice.getTotalBeforeTax().setScale(2).toString(), new Font(FontFamily.HELVETICA, 12, Font.BOLD)));
		cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase("Tax (CGST - 2.5%)" ));
		cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setPadding(5f);
		cell.setColspan(2);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase(invoice.getcGST().setScale(2).toString()));
		cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase("Tax (SGST - 2.5%)" ));
		cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setPadding(5f);
		cell.setColspan(2);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase(invoice.getsGST().setScale(2).toString()));
		cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setPadding(5f);
		detail.addCell(cell);
		
		cell = new PdfPCell(new Phrase("Total Amount After Tax", new Font(FontFamily.HELVETICA, 12, Font.BOLD) ));
		cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setPadding(5f);
		cell.setColspan(2);
		detail.addCell(cell);
			
		cell = new PdfPCell(new Phrase(invoice.getTotalAfterTax().setScale(2).toString(), new Font(FontFamily.HELVETICA, 12, Font.BOLD)));
		cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setPadding(5f);
		detail.addCell(cell);
								
		main.addCell(new PdfPCell(detail));
		
		cell = new PdfPCell(new Phrase("Terms & Conditions: ", new Font(FontFamily.HELVETICA, 12, Font.BOLD)));
		cell.setVerticalAlignment(Element.ALIGN_TOP);
		cell.setPadding(5f);
		cell.setMinimumHeight(100f);
		main.addCell(cell);
		
		return main;
	}

}



