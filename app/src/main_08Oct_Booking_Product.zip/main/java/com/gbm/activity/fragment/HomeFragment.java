package com.gbm.activity.fragment;

import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.gbm.activity.LoginActivity;
import com.gbm.activity.R;
import com.gbm.db.GBMDBUtils;
import com.gbm.utils.SessionManager;
import com.gbm.vo.BookingVO;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * Created by Sri on 9/12/2017.
 */

public class HomeFragment extends Fragment {

    private static final String TAG = "HomeFragment";
    private SessionManager session;
    private View homeView;
    GBMDBUtils dbUtils;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        session =  new SessionManager(getContext());
        session.checkLogin();

        homeView = inflater.inflate(R.layout.fragment_home, container, false);

        TableLayout _iconsTblLayout = (TableLayout) homeView.findViewById(R.id.tbl_icons);
        TableRow row;
        Button button;
        if("Administrator".equals(session.getRole())) {

            row = new TableRow(getContext());
            row.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
            row.setBackgroundResource(R.drawable.cell_shape);

            button = new Button(getContext());
            button.setText("Users");
            button.setBackgroundColor(getResources().getColor(R.color.white));
            button.setCompoundDrawablesWithIntrinsicBounds(0, R.mipmap.ic_icon_users, 0, 0);
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Fragment fragment = new SearchUserFragment();
                    FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
                    ft.replace(R.id.content_frame, fragment);
                    ft.commit();
                    setTitle("Users");
                }
            });

            row.addView(button);

            button = new Button(getContext());
            button.setText("Clear Data");
            button.setBackgroundColor(getResources().getColor(R.color.white));
            button.setCompoundDrawablesWithIntrinsicBounds(0, R.mipmap.ic_icon_clear, 0, 0);
            row.addView(button);


            _iconsTblLayout.addView(row);

            row = new TableRow(getContext());
            row.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
            row.setBackgroundResource(R.color.white);

            row.addView(getLogoutButton());

            _iconsTblLayout.addView(row);

        } else if("Invoice".equals(session.getRole())) {
            row = new TableRow(getContext());
            row.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
            row.setBackgroundResource(R.drawable.cell_shape);

            button = new Button(getContext());
            button.setText("Invoice");
            button.setBackgroundColor(getResources().getColor(R.color.white));
            button.setCompoundDrawablesWithIntrinsicBounds(0, R.mipmap.ic_icon_invoice, 0, 0);
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Fragment fragment = new SearchInvoiceFragment();
                    FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
                    ft.replace(R.id.content_frame, fragment);
                    ft.commit();
                    setTitle("Invoice");
                }
            });

            row.addView(button);

            row.addView(getLogoutButton());

            _iconsTblLayout.addView(row);

        } else if("Booking".equals(session.getRole())) {
            row = new TableRow(getContext());
            row.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
            row.setBackgroundResource(R.drawable.cell_shape);

            button = new Button(getContext());
            button.setText("Invoice");
            button.setBackgroundColor(getResources().getColor(R.color.white));
            button.setCompoundDrawablesWithIntrinsicBounds(0, R.mipmap.ic_icon_invoice, 0, 0);
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Fragment fragment = new SearchInvoiceFragment();
                    FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
                    ft.replace(R.id.content_frame, fragment);
                    ft.commit();
                    setTitle("Invoice");
                }
            });

            row.addView(button);

            button = new Button(getContext());
            button.setText("Booking");
            button.setBackgroundColor(getResources().getColor(R.color.white));
            button.setCompoundDrawablesWithIntrinsicBounds(0, R.mipmap.ic_icon_booking, 0, 0);
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Fragment fragment = new SearchBookingFragment();
                    FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
                    ft.replace(R.id.content_frame, fragment);
                    ft.commit();
                    setTitle("Booking");
                }
            });

            row.addView(button);

            _iconsTblLayout.addView(row);

            row = new TableRow(getContext());
            row.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
            row.setBackgroundResource(R.drawable.cell_shape);

            button = new Button(getContext());
            button.setText("Credits");
            button.setBackgroundColor(getResources().getColor(R.color.white));
            button.setCompoundDrawablesWithIntrinsicBounds(0, R.mipmap.ic_icon_credit, 0, 0);
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Fragment fragment = new SearchCreditFragment();
                    FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
                    ft.replace(R.id.content_frame, fragment);
                    ft.commit();
                    setTitle("Credits");
                }
            });

            row.addView(button);

            row.addView(getLogoutButton());

            _iconsTblLayout.addView(row);
        }

        return homeView;
    }

    private Button getLogoutButton() {
        Button button = new Button(getContext());
        button.setText("Logout");
        button.setBackgroundColor(getResources().getColor(R.color.white));
        button.setCompoundDrawablesWithIntrinsicBounds(0, R.mipmap.ic_icon_logout, 0, 0);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(session != null) {
                    session.logoutUser();
                }
                Toast.makeText(getContext(), "User logged out successfully", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(getContext(), LoginActivity.class);
                getActivity().finish();
                getContext().startActivity(intent);
            }
        });
        return button;
    }

    private void setTitle(String title) {
        ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle(title);
    }

}

