package com.gbm.vo;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Created by Sri on 9/6/2017.
 */

public class CreditVO implements Serializable {

    private long id;
    private String bookingNo;
    private String bookingDt;
    private String receiverName;
    private String vehicleNo;
    private BigDecimal total;
    private BigDecimal paid;
    private BigDecimal balance;
    private BookingVO booking;


    public CreditVO() {

    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getBookingNo() {
        return bookingNo;
    }

    public void setBookingNo(String bookingNo) {
        this.bookingNo = bookingNo;
    }

    public String getBookingDt() {
        return bookingDt;
    }

    public void setBookingDt(String bookingDt) {
        this.bookingDt = bookingDt;
    }

    public String getReceiverName() {
        return receiverName;
    }

    public void setReceiverName(String receiverName) {
        this.receiverName = receiverName;
    }

    public String getVehicleNo() {
        return vehicleNo;
    }

    public void setVehicleNo(String vehicleNo) {
        this.vehicleNo = vehicleNo;
    }

    public BigDecimal getTotal() {
        return total;
    }

    public void setTotal(BigDecimal total) {
        this.total = total;
    }

    public BigDecimal getPaid() {
        return paid;
    }

    public void setPaid(BigDecimal paid) {
        this.paid = paid;
    }

    public BigDecimal getBalance() {
        return balance;
    }

    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }

    public BookingVO getBooking() {
        return booking;
    }

    public void setBooking(BookingVO booking) {
        this.booking = booking;
    }
}
