package com.gbm.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.regex.Pattern;

import com.gbm.vo.BookingVO;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class PDFCreatorBooking extends AbstractPDFCreator {

    @Override
    public <T> PdfPTable generatePDFContent(T t) {

        BookingVO booking = (BookingVO) t;

        PdfPTable main = new PdfPTable(1);
        main.setWidthPercentage(100);

        PdfPTable detail = new PdfPTable(4);
        detail.setWidthPercentage(100);

        PdfPCell cell;

        cell = new PdfPCell(new Phrase("GEMINI BLUE METAL WORKS", new Font(FontFamily.HELVETICA, 25, Font.BOLD)));
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setColspan(4);
        cell.setPadding(5f);
        cell.setBorder(Rectangle.NO_BORDER);
        detail.addCell(cell);

        cell = new PdfPCell(new Phrase("73/3, Veppamara Salai, Alangayam Road, Vaniyambadi - 635752. Vellore Dt",
                new Font(FontFamily.HELVETICA, 9)));
        cell.setColspan(4);
        cell.setPadding(5f);
        cell.setBorder(Rectangle.NO_BORDER);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        detail.addCell(cell);

        main.addCell(new PdfPCell(detail));

        detail = new PdfPTable(3);
        detail.setWidthPercentage(100);

        cell = new PdfPCell(new Phrase("Booking No.: " + booking.getBookingNo()));
        cell.setPadding(5f);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        detail.addCell(cell);

        cell = new PdfPCell(new Phrase("BOOKING DETAILS", new Font(FontFamily.HELVETICA, 12, Font.BOLD)));
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setPadding(5f);
        detail.addCell(cell);

        cell = new PdfPCell(new Phrase("Booking Date: " + booking.getBookingDt()));
        cell.setPadding(5f);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        detail.addCell(cell);

        main.addCell(new PdfPCell(detail));


        cell = new PdfPCell(new Phrase("Details of Receiver / Buyer", new Font(FontFamily.HELVETICA, 12, Font.BOLD)));
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setPadding(5f);
        main.addCell(cell);

        detail = new PdfPTable(new float[]{20f, 90f});
        detail.setTotalWidth(100f);

        cell = new PdfPCell(new Phrase("Name: "));
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setBorder(Rectangle.NO_BORDER);
        cell.setPadding(5f);
        detail.addCell(cell);

        cell = new PdfPCell(new Phrase(booking.getReceiverName()));
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setBorder(Rectangle.NO_BORDER);
        cell.setPadding(5f);
        detail.addCell(cell);

        cell = new PdfPCell(new Phrase("Address: "));
        cell.setVerticalAlignment(Element.ALIGN_TOP);
        cell.setBorder(Rectangle.NO_BORDER);
        cell.setPadding(5f);
        detail.addCell(cell);

        cell = new PdfPCell(new Phrase(booking.getAddress()));
        cell.setVerticalAlignment(Element.ALIGN_TOP);
        cell.setBorder(Rectangle.NO_BORDER);
        cell.setPadding(5f);
        detail.addCell(cell);

        cell = new PdfPCell(new Phrase("Phone: "));
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setBorder(Rectangle.NO_BORDER);
        cell.setPadding(5f);
        detail.addCell(cell);

        cell = new PdfPCell(new Phrase(booking.getPhone()));
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setBorder(Rectangle.NO_BORDER);
        cell.setPadding(5f);
        detail.addCell(cell);

        main.addCell(new PdfPCell(detail));

        detail = new PdfPTable(new float[]{1f, 5f, 2f, 2f});
        detail.setWidthPercentage(100);

        cell = new PdfPCell(new Phrase("Sr. No.", new Font(FontFamily.HELVETICA, 12, Font.BOLD)));
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setPadding(5f);
        detail.addCell(cell);

        cell = new PdfPCell(new Phrase("Name of Product / Commodity", new Font(FontFamily.HELVETICA, 12, Font.BOLD)));
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setPadding(5f);
        detail.addCell(cell);

        cell = new PdfPCell(new Phrase("Qty", new Font(FontFamily.HELVETICA, 12, Font.BOLD)));
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setPadding(5f);
        detail.addCell(cell);

        cell = new PdfPCell(new Phrase("Rate", new Font(FontFamily.HELVETICA, 12, Font.BOLD)));
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setPadding(5f);
        detail.addCell(cell);

        cell = new PdfPCell(new Phrase("1"));
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setPadding(5f);
        detail.addCell(cell);

        cell = new PdfPCell(new Phrase(booking.getItem()));
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setPadding(5f);
        detail.addCell(cell);

        cell = new PdfPCell(new Phrase(booking.getQuantity().toString()));
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setPadding(5f);
        detail.addCell(cell);

        cell = new PdfPCell(new Phrase(booking.getPrice().toString()));
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setPadding(5f);
        detail.addCell(cell);

        String[] total = booking.getTotal().toString().split(Pattern.quote("."));

        Phrase inWords = new Phrase();
        inWords.add(new Chunk("Total Amount in Words:  \n\n", new Font(FontFamily.HELVETICA, 12, Font.BOLD)));
        inWords.add(new Chunk(NumberToWord.convert(total[0]) + " Only "));

        cell = new PdfPCell(inWords);
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_TOP);
        cell.setPadding(5f);
        cell.setColspan(2);
        cell.setRowspan(4);
        detail.addCell(cell);

        cell = new PdfPCell(new Phrase("Rent"));
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setPadding(5f);
        detail.addCell(cell);

        cell = new PdfPCell(new Phrase(booking.getRent().toString()));
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setPadding(5f);
        detail.addCell(cell);

        cell = new PdfPCell(new Phrase("Total", new Font(FontFamily.HELVETICA, 12, Font.BOLD)));
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setPadding(5f);
        detail.addCell(cell);

        cell = new PdfPCell(new Phrase(booking.getTotal().toString(), new Font(FontFamily.HELVETICA, 12, Font.BOLD)));
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setPadding(5f);
        detail.addCell(cell);

        cell = new PdfPCell(new Phrase("Advance"));
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setPadding(5f);
        detail.addCell(cell);

        cell = new PdfPCell(new Phrase(booking.getAdvance().toString()));
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setPadding(5f);
        detail.addCell(cell);

        cell = new PdfPCell(new Phrase("Balance", new Font(FontFamily.HELVETICA, 12, Font.BOLD)));
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setPadding(5f);
        detail.addCell(cell);

        cell = new PdfPCell(new Phrase(booking.getBalance().toString(), new Font(FontFamily.HELVETICA, 12, Font.BOLD)));
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setPadding(5f);
        detail.addCell(cell);

        main.addCell(new PdfPCell(detail));

        cell = new PdfPCell(new Phrase("Terms & Conditions: ", new Font(FontFamily.HELVETICA, 12, Font.BOLD)));
        cell.setVerticalAlignment(Element.ALIGN_TOP);
        cell.setPadding(5f);
        cell.setMinimumHeight(100f);
        main.addCell(cell);

        return main;
    }

}



