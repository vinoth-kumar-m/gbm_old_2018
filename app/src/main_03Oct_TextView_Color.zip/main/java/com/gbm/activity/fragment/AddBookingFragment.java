package com.gbm.activity.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.gbm.activity.R;
import com.gbm.db.GBMDBUtils;
import com.gbm.vo.BookingVO;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * Created by Sri on 9/12/2017.
 */

public class AddBookingFragment extends Fragment {

    private static final String TAG = "AddBookingFragment";
    private String roleSelected;
    private View addBookingView;
    GBMDBUtils dbUtils;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the dropdown_item for this fragment
        addBookingView = inflater.inflate(R.layout.fragment_booking_add, container, false);

        dbUtils = new GBMDBUtils(getContext());

        final EditText _bookingNo = (EditText) addBookingView.findViewById(R.id.input_bookingNo);
        _bookingNo.setText(dbUtils.getBookingNumber());

        final Calendar myCalendar = Calendar.getInstance();

        final EditText _bookingDate = (EditText) addBookingView.findViewById(R.id.input_bookingDate);
        _bookingDate.setText(new SimpleDateFormat("dd/MM/yyyy HH:mm").format(myCalendar.getTime()));

        final EditText _receiverName = (EditText) addBookingView.findViewById(R.id.input_receiverName);
        final EditText _receiverAddress = (EditText) addBookingView.findViewById(R.id.input_receiverAddress);
        final EditText _item = (EditText) addBookingView.findViewById(R.id.input_item);
        final EditText _quantity = (EditText) addBookingView.findViewById(R.id.input_quantity);
        final EditText _price = (EditText) addBookingView.findViewById(R.id.input_price);
        final EditText _total = (EditText) addBookingView.findViewById(R.id.input_total);
        final EditText _rent = (EditText) addBookingView.findViewById(R.id.input_rent);
        final EditText _advance = (EditText) addBookingView.findViewById(R.id.input_advance);

        Button _saveButton = (Button) addBookingView.findViewById(R.id.btn_save);

        _quantity.setOnFocusChangeListener(getFocusChangeListener());
        _price.setOnFocusChangeListener(getFocusChangeListener());
        _rent.setOnFocusChangeListener(getFocusChangeListener());
        _advance.setOnFocusChangeListener(getFocusChangeListener());

        _price.addTextChangedListener(getTextWatcher());
        _rent.addTextChangedListener(getTextWatcher());
        _advance.addTextChangedListener(getTextWatcher());

        _saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean valid = true;

                if (_receiverName.getText().toString().isEmpty()) {
                    _receiverName.setError("Receiver / Buyer Name is required");
                    valid = false;
                } else {
                    _receiverName.setError(null);
                }

                if (_receiverAddress.getText().toString().isEmpty()) {
                    _receiverAddress.setError("Address is required");
                    valid = false;
                } else {
                    _receiverAddress.setError(null);
                }

                if (_item.getText().toString().isEmpty()) {
                    _item.setError("Item is required");
                    valid = false;
                } else {
                    _item.setError(null);
                }

                if (_quantity.getText().toString().isEmpty()) {
                    _quantity.setError("Quantity is required");
                    valid = false;
                } else {
                    _quantity.setError(null);
                }

                if (_price.getText().toString().isEmpty()) {
                    _price.setError("Price is required");
                    valid = false;
                } else {
                    _price.setError(null);
                }

                if (_rent.getText().toString().isEmpty()) {
                    _rent.setError("Rent is required");
                    valid = false;
                } else {
                    _rent.setError(null);
                }

                if (_advance.getText().toString().isEmpty()) {
                    _advance.setError("Advance is required");
                    valid = false;
                } else {
                    _advance.setError(null);
                }



                if(!valid) {
                    return;
                } else {
                    BigDecimal total = new BigDecimal(_total.getText().toString());
                    BigDecimal advance = new BigDecimal(_advance.getText().toString());
                    if (advance.compareTo(total) > 0) {
                        Toast.makeText(getContext(), "Advance Amount cannot be greater than Total Amount", Toast.LENGTH_LONG).show();
                        return;
                    }
                }

                saveBooking();
            }
        });

        Button _closeButton = (Button) addBookingView.findViewById(R.id.btn_close);

        _closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment fragment = new SearchBookingFragment();
                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.content_frame, fragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });

        return addBookingView;
    }

    private View.OnFocusChangeListener getFocusChangeListener() {
        return new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean hasFocus) {
                if (!hasFocus) {
                    EditText _amount = (EditText) view;
                    if (!_amount.getText().toString().isEmpty()) {
                        BigDecimal amount = new BigDecimal(_amount.getText().toString()).setScale(2, BigDecimal.ROUND_HALF_UP);
                        _amount.setText(amount.toString());
                    }
                    calculateAmount();
                }
            }
        };
    }

    private TextWatcher getTextWatcher() {
        return new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) { }

            @Override
            public void afterTextChanged(Editable s) {
                calculateAmount();
            }
        };
    }


    private void calculateAmount() {
        final EditText _price = (EditText) addBookingView.findViewById(R.id.input_price);
        final EditText _rent = (EditText) addBookingView.findViewById(R.id.input_rent);
        final EditText _total = (EditText) addBookingView.findViewById(R.id.input_total);
        final EditText _advance = (EditText) addBookingView.findViewById(R.id.input_advance);
        final EditText _balance = (EditText) addBookingView.findViewById(R.id.input_balance);

        BigDecimal price = BigDecimal.ZERO;
        BigDecimal rent = BigDecimal.ZERO;
        BigDecimal advance = BigDecimal.ZERO;

        if(!_price.getText().toString().isEmpty()) {
            price = new BigDecimal(_price.getText().toString()).setScale(2, BigDecimal.ROUND_HALF_UP);
        }

        if(!_rent.getText().toString().isEmpty()) {
            rent = new BigDecimal(_rent.getText().toString()).setScale(2, BigDecimal.ROUND_HALF_UP);
        }

        if(!_advance.getText().toString().isEmpty()) {
            advance = new BigDecimal(_advance.getText().toString()).setScale(2, BigDecimal.ROUND_HALF_UP);
        }
        BigDecimal total = price.add(rent).setScale(2, BigDecimal.ROUND_HALF_UP);
        BigDecimal balance = total.subtract(advance).setScale(2, BigDecimal.ROUND_HALF_UP);
        _total.setText(total.toString());
        _balance.setText(balance.toString());
    }

    private void saveBooking() {
        final EditText _bookingNo = (EditText) addBookingView.findViewById(R.id.input_bookingNo);
        final EditText _bookingDate = (EditText) addBookingView.findViewById(R.id.input_bookingDate);
        final EditText _receiverName = (EditText) addBookingView.findViewById(R.id.input_receiverName);
        final EditText _receiverAddress = (EditText) addBookingView.findViewById(R.id.input_receiverAddress);
        final EditText _phone = (EditText) addBookingView.findViewById(R.id.input_receiverPhoneNo);
        final EditText _item = (EditText) addBookingView.findViewById(R.id.input_item);
        final EditText _quantity = (EditText) addBookingView.findViewById(R.id.input_quantity);
        final EditText _price = (EditText) addBookingView.findViewById(R.id.input_price);
        final EditText _rent = (EditText) addBookingView.findViewById(R.id.input_rent);
        final EditText _total = (EditText) addBookingView.findViewById(R.id.input_total);
        final EditText _advance = (EditText) addBookingView.findViewById(R.id.input_advance);
        final EditText _balance = (EditText) addBookingView.findViewById(R.id.input_balance);

        BookingVO booking = new BookingVO();
        booking.setBookingNo(_bookingNo.getText().toString());
        booking.setBookingDt(_bookingDate.getText().toString());
        booking.setReceiverName(_receiverName.getText().toString());
        booking.setAddress(_receiverAddress.getText().toString());
        booking.setPhone(_phone.getText().toString());
        booking.setItem(_item.getText().toString());
        booking.setQuantity(new BigDecimal(_quantity.getText().toString()).setScale(2, BigDecimal.ROUND_HALF_UP));
        booking.setPrice(new BigDecimal(_price.getText().toString()).setScale(2, BigDecimal.ROUND_HALF_UP));
        booking.setRent(new BigDecimal(_rent.getText().toString()).setScale(2, BigDecimal.ROUND_HALF_UP));
        booking.setTotal(new BigDecimal(_total.getText().toString()).setScale(2, BigDecimal.ROUND_HALF_UP));
        booking.setAdvance(new BigDecimal(_advance.getText().toString()).setScale(2, BigDecimal.ROUND_HALF_UP));
        booking.setBalance(new BigDecimal(_balance.getText().toString()).setScale(2, BigDecimal.ROUND_HALF_UP));

        long id = dbUtils.saveBooking(booking);
        if(id > 0) {
            Toast.makeText(getContext(), "Booking saved successfully", Toast.LENGTH_LONG).show();
            Fragment fragment = new SearchBookingFragment();
            FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.content_frame, fragment);
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.commit();
        }
    }
}

