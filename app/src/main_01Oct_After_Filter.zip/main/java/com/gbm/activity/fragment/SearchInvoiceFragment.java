package com.gbm.activity.fragment;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TableRow.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;

import com.gbm.activity.R;
import com.gbm.db.GBMDBUtils;
import com.gbm.vo.InvoiceVO;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

/**
 * Created by Sri on 9/12/2017.
 */

public class SearchInvoiceFragment extends Fragment {

    private static final String TAG = "SearchInvoiceFragment";
    private String roleSelected;
    private View searchInvoiceView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        searchInvoiceView = inflater.inflate(R.layout.fragment_invoice_search, container, false);

        Button _searchButton = (Button) searchInvoiceView.findViewById(R.id.btn_search);

        _searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchInvoice();
            }
        });

        Button _addButton = (Button) searchInvoiceView.findViewById(R.id.btn_add);

        _addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment fragment = new AddInvoiceFragment();
                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.content_frame, fragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });

        final Calendar myCalendar = Calendar.getInstance();

        final EditText _invoiceDate = (EditText) searchInvoiceView.findViewById(R.id.input_invoiceDate);
        _invoiceDate.setText(new SimpleDateFormat("dd/MM/yyyy").format(myCalendar.getTime()));
        _invoiceDate.setOnClickListener(new View.OnClickListener() {
            DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                    // TODO Auto-generated method stub
                    myCalendar.set(Calendar.YEAR, year);
                    myCalendar.set(Calendar.MONTH, monthOfYear);
                    myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                    _invoiceDate.setText(new SimpleDateFormat("dd/MM/yyyy").format(myCalendar.getTime()));
                }
            };

            @Override
            public void onClick(View v) {
                new DatePickerDialog(getContext(), date, myCalendar.get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        final EditText _supplyDate = (EditText) searchInvoiceView.findViewById(R.id.input_supplyDate);
        _supplyDate.setOnClickListener(new View.OnClickListener() {
            DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                    // TODO Auto-generated method stub
                    myCalendar.set(Calendar.YEAR, year);
                    myCalendar.set(Calendar.MONTH, monthOfYear);
                    myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                    _supplyDate.setText(new SimpleDateFormat("dd/MM/yyyy").format(myCalendar.getTime()));
                }
            };

            @Override
            public void onClick(View v) {
                new DatePickerDialog(getContext(), date, myCalendar.get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        searchInvoice();

        return searchInvoiceView;
    }

    private void populateInvoices(List<InvoiceVO> invoices) {
        TableLayout _invoicesTblLayout = (TableLayout) searchInvoiceView.findViewById(R.id.tbl_invoices);
        for (int i = 0; i < _invoicesTblLayout.getChildCount(); i++) {
            View child = _invoicesTblLayout.getChildAt(i);
            if (child instanceof TableRow) ((ViewGroup) child).removeAllViews();
        }

        Log.d(TAG, "Populating Invoices...");
        TableRow row = new TableRow(getContext());
        row.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        row.setBackgroundResource(R.drawable.cell_shape);

        ImageView image = new ImageView(getContext());
        image.setImageResource(R.drawable.ic_menu_edit);
        image.setPadding(5, 5, 5, 5);
        row.addView(image);

        TextView tv = new TextView(getContext());
        tv.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
        tv.setPadding(5, 5, 5, 5);
        tv.setText("Invoice No");
        row.addView(tv);

        /*tv = new TextView(getContext());
        tv.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
        tv.setPadding(5, 5, 5, 5);
        tv.setText("Invoice Date");
        row.addView(tv);*/

        tv = new TextView(getContext());
        tv.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
        tv.setPadding(5, 5, 5, 5);
        tv.setText("Receiver Name");
        row.addView(tv);

        tv = new TextView(getContext());
        tv.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
        tv.setPadding(5, 5, 5, 5);
        tv.setText("Amount");
        row.addView(tv);

        _invoicesTblLayout.addView(row);

        for (InvoiceVO invoice : invoices) {
            row = new TableRow(getContext());
            row.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
            row.setBackgroundResource(R.drawable.cell_shape);

            image = new ImageView(getContext());
            image.setTag(invoice);
            image.setImageResource(R.drawable.ic_menu_edit);
            image.setPadding(5, 5, 5, 5);
            image.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle bundle=new Bundle();
                    bundle.putSerializable("invoice", (InvoiceVO) v.getTag());
                    Fragment fragment = new ViewInvoiceFragment();
                    fragment.setArguments(bundle);
                    FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.content_frame, fragment);
                    fragmentTransaction.addToBackStack(null);
                    fragmentTransaction.commit();
                }
            });
            row.addView(image);

            tv = new TextView(getContext());
            tv.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
            tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
            tv.setPadding(5, 5, 5, 5);
            tv.setText(invoice.getInvoiceNo());
            row.addView(tv);

            /*tv = new TextView(getContext());
            tv.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
            tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
            tv.setPadding(5, 5, 5, 5);
            tv.setText(invoice.getInvoiceDt());
            row.addView(tv);*/

            tv = new TextView(getContext());
            tv.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
            tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
            tv.setPadding(5, 5, 5, 5);
            tv.setText(invoice.getReceiverName());
            row.addView(tv);

            tv = new TextView(getContext());
            tv.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
            tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
            tv.setPadding(5, 5, 5, 5);
            tv.setText(String.valueOf(invoice.getTotalAfterTax().setScale(2)));
            row.addView(tv);

            _invoicesTblLayout.addView(row);
        }
    }

    public void searchInvoice() {
        Log.d(TAG, "Searching Invoice...");

        final EditText _invoiceNo = (EditText) searchInvoiceView.findViewById(R.id.input_invoiceNo);
        final EditText _invoiceDate = (EditText) searchInvoiceView.findViewById(R.id.input_invoiceDate);
        final EditText _supplyDate = (EditText) searchInvoiceView.findViewById(R.id.input_supplyDate);
        final EditText _receiverName = (EditText) searchInvoiceView.findViewById(R.id.input_receiverName);

        InvoiceVO invoice = new InvoiceVO();
        invoice.setInvoiceNo(_invoiceNo.getText().toString());
        invoice.setInvoiceDt(_invoiceDate.getText().toString());
        invoice.setSupplyDt(_supplyDate.getText().toString());
        invoice.setReceiverName(_receiverName.getText().toString());

        final ProgressDialog progressDialog = new ProgressDialog(getContext(), R.style.AppTheme_Dark_Dialog);
        progressDialog.setIndeterminate(true);
        progressDialog.setMessage("Searching...");
        progressDialog.show();
        GBMDBUtils dbUtils = new GBMDBUtils(getContext());
        List<InvoiceVO> invoices = dbUtils.getInvoices(invoice);

        if(invoices == null || invoices.isEmpty()) {
            Toast.makeText(getContext(), "No data found", Toast.LENGTH_LONG).show();
            progressDialog.dismiss();
        }
        else {
            populateInvoices(invoices);
            progressDialog.dismiss();
        }

    }
}

