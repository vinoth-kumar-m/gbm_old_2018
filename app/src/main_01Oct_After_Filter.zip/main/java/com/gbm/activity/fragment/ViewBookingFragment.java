package com.gbm.activity.fragment;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.FileProvider;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.gbm.activity.R;
import com.gbm.constants.GBMConstants;
import com.gbm.utils.PDFCreator;
import com.gbm.utils.PDFCreatorFactory;
import com.gbm.vo.BookingVO;

import java.io.File;

/**
 * Created by Sri on 9/12/2017.
 */

public class ViewBookingFragment extends Fragment {

    private static final String TAG = "ViewBookingFragment";
    private String roleSelected;
    private View bookingView;
    BookingVO booking;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        bookingView = inflater.inflate(R.layout.fragment_booking_view, container, false);

        booking = (BookingVO) getArguments().getSerializable("booking");

        final EditText _bookingNo = (EditText) bookingView.findViewById(R.id.input_bookingNo);
        final EditText _bookingDate = (EditText) bookingView.findViewById(R.id.input_bookingDate);
        final EditText _receiverName = (EditText) bookingView.findViewById(R.id.input_receiverName);
        final EditText _receiverAddress = (EditText) bookingView.findViewById(R.id.input_receiverAddress);
        final EditText _phone = (EditText) bookingView.findViewById(R.id.input_receiverPhoneNo);
        final EditText _item = (EditText) bookingView.findViewById(R.id.input_item);
        final EditText _quantity = (EditText) bookingView.findViewById(R.id.input_quantity);
        final EditText _price = (EditText) bookingView.findViewById(R.id.input_price);
        final EditText _rent = (EditText) bookingView.findViewById(R.id.input_rent);
        final EditText _total = (EditText) bookingView.findViewById(R.id.input_total);
        final EditText _advance = (EditText) bookingView.findViewById(R.id.input_advance);
        final EditText _balance = (EditText) bookingView.findViewById(R.id.input_balance);

        _bookingNo.setText(booking.getBookingNo());
        _bookingDate.setText(booking.getBookingDt());
        _receiverName.setText(booking.getReceiverName());
        _receiverAddress.setText(booking.getAddress());
        _phone.setText(booking.getPhone());
        _item.setText(booking.getItem());
        _quantity.setText(String.valueOf(booking.getQuantity().setScale(2)));
        _price.setText(String.valueOf(booking.getPrice().setScale(2)));
        _rent.setText(String.valueOf(booking.getRent().setScale(2)));
        _total.setText(String.valueOf(booking.getTotal().setScale(2)));
        _advance.setText(String.valueOf(booking.getAdvance().setScale(2)));
        _balance.setText(String.valueOf(booking.getBalance().setScale(2)));

        Button _printButton = (Button) bookingView.findViewById(R.id.btn_print);

        _printButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    PDFCreator pdfCreator = PDFCreatorFactory.getInstance(GBMConstants.BOOKING);
                    File file = pdfCreator.createPDF(getContext(), booking.getBookingNo() + ".pdf", booking);
                    viewPDF(file);
                } catch(Exception ex) {
                    Log.e(TAG, ex.getLocalizedMessage());
                }
            }
        });

        Button _closeButton = (Button) bookingView.findViewById(R.id.btn_close);

        _closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment fragment = new SearchBookingFragment();
                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.content_frame, fragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });

        return bookingView;
    }

    private void viewPDF(File file){
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(FileProvider.getUriForFile(getContext(), "com.gbm.provider", file), "application/pdf");
            intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(intent);
        } catch (Exception e) {
            Log.i("error", e.getLocalizedMessage());
        }
    }
}

