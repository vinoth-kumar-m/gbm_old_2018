package com.gbm.activity.fragment;

import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.gbm.activity.R;
import com.gbm.db.GBMDBUtils;
import com.gbm.vo.BookingVO;
import com.gbm.vo.CreditVO;
import com.gbm.vo.ProductVO;

import java.math.BigDecimal;

/**
 * Created by Sri on 9/12/2017.
 */

public class ViewCreditFragment extends Fragment {

    private static final String TAG = "ViewCreditFragment";
    private View creditView;
    CreditVO credit;
    GBMDBUtils dbUtils;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the dropdown_item for this fragment
        creditView = inflater.inflate(R.layout.fragment_credit_view, container, false);
        dbUtils = new GBMDBUtils(getContext());
        credit = (CreditVO) getArguments().getSerializable("credit");

        final EditText _bookingNo = (EditText) creditView.findViewById(R.id.input_bookingNo);
        final EditText _bookingDate = (EditText) creditView.findViewById(R.id.input_bookingDate);
        final EditText _receiverName = (EditText) creditView.findViewById(R.id.input_receiverName);
        final EditText _total = (EditText) creditView.findViewById(R.id.input_total);
        final EditText _paid = (EditText) creditView.findViewById(R.id.input_paid);
        final EditText _balance = (EditText) creditView.findViewById(R.id.input_balance);
        final EditText _vehicleNo = (EditText) creditView.findViewById(R.id.input_vehicleNo);
        final EditText _settlementAmount = (EditText) creditView.findViewById(R.id.input_amount);

        _bookingNo.setText(credit.getBookingNo());
        _bookingDate.setText(credit.getBookingDt());
        _receiverName.setText(credit.getReceiverName());
        _total.setText(String.valueOf(credit.getAmount().setScale(2)));

        _vehicleNo.setText(credit.getVehicleNo());

        _settlementAmount.setOnFocusChangeListener(getFocusChangeListener());


        Button _saveButton = (Button) creditView.findViewById(R.id.btn_save);
        _saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(_vehicleNo.getText().toString().isEmpty() && _settlementAmount.getText().toString().isEmpty()) {
                    Toast.makeText(getContext(), "No changes to save", Toast.LENGTH_LONG).show();
                    return;
                }
                credit.setVehicleNo(_vehicleNo.getText().toString());
                BigDecimal balance = new BigDecimal(_balance.getText().toString());
                if(!_settlementAmount.getText().toString().isEmpty()) {
                    BigDecimal settlementAmount = new BigDecimal(_settlementAmount.getText().toString());
                    if(settlementAmount.compareTo(balance) > 0) {
                        Toast.makeText(getContext(), "Settlement Amount cannot be greater than Balance", Toast.LENGTH_LONG).show();
                        return;
                    }
                    BigDecimal paid = BigDecimal.ZERO;
                    if(!_paid.getText().toString().isEmpty()) {
                        paid = new BigDecimal(_paid.getText().toString());
                    }
                    paid = paid.add(settlementAmount).setScale(2, BigDecimal.ROUND_HALF_UP);
                    balance = balance.subtract(settlementAmount).setScale(2, BigDecimal.ROUND_HALF_UP);
                    _paid.setText(paid.toString());
                    _balance.setText(balance.toString());

                }
                int count = 1;
                if(count > 0) {
                    Toast.makeText(getContext(), "Credit details updated", Toast.LENGTH_LONG).show();
                    Fragment fragment = new SearchCreditFragment();
                    FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.content_frame, fragment);
                    fragmentTransaction.addToBackStack(null);
                    fragmentTransaction.commit();
                }
            }
        });

        Button _closeButton = (Button) creditView.findViewById(R.id.btn_close);

        _closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment fragment = new SearchCreditFragment();
                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.content_frame, fragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });

        return creditView;
    }

    private View.OnFocusChangeListener getFocusChangeListener() {
        return new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean hasFocus) {
                if (!hasFocus) {
                    EditText _amount = (EditText) view;
                    if (!_amount.getText().toString().isEmpty()) {
                        BigDecimal amount = new BigDecimal(_amount.getText().toString()).setScale(2, BigDecimal.ROUND_HALF_UP);
                        _amount.setText(amount.toString());
                    }
                }
            }
        };
    }

    private void populateProducts(Dialog bookingDialog, BookingVO booking) {
        TableLayout _productsTblLayout = (TableLayout) bookingDialog.findViewById(R.id.tbl_products);
        for (int i = 0; i < _productsTblLayout.getChildCount(); i++) {
            View child = _productsTblLayout.getChildAt(i);
            if (child instanceof TableRow) ((ViewGroup) child).removeAllViews();
        }

        Log.d(TAG, "Populating Products...");
        TableRow row = new TableRow(getContext());
        row.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
        row.setBackgroundResource(R.drawable.cell_shape);

        TextView tv = new TextView(getContext());
        tv.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT));
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
        tv.setTextColor(getResources().getColor(R.color.primary_dark));
        tv.setPadding(5, 5, 5, 5);
        tv.setText("Product");
        row.addView(tv);

        tv = new TextView(getContext());
        tv.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT));
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
        tv.setTextColor(getResources().getColor(R.color.primary_dark));
        tv.setPadding(5, 5, 5, 5);
        tv.setText("HSN");
        row.addView(tv);

        tv = new TextView(getContext());
        tv.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT));
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
        tv.setTextColor(getResources().getColor(R.color.primary_dark));
        tv.setPadding(5, 5, 5, 5);
        tv.setText("Qty");
        row.addView(tv);

        tv = new TextView(getContext());
        tv.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT));
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
        tv.setTextColor(getResources().getColor(R.color.primary_dark));
        tv.setPadding(5, 5, 5, 5);
        tv.setText("Price");
        row.addView(tv);

        tv = new TextView(getContext());
        tv.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT));
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
        tv.setTextColor(getResources().getColor(R.color.primary_dark));
        tv.setPadding(5, 5, 5, 5);
        tv.setText("Total");
        row.addView(tv);

        _productsTblLayout.addView(row);
        int idx = 0;
        if(booking != null) {
            for (ProductVO product : booking.getProducts()) {
                row = new TableRow(getContext());
                row.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
                row.setBackgroundResource(R.drawable.cell_shape);

                tv = new TextView(getContext());
                tv.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT));
                tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
                tv.setPadding(5, 5, 5, 5);
                tv.setText(product.getName());
                row.addView(tv);

                tv = new TextView(getContext());
                tv.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT));
                tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
                tv.setPadding(5, 5, 5, 5);
                tv.setText(product.getHsnCode());
                row.addView(tv);

                tv = new TextView(getContext());
                tv.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT));
                tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
                tv.setPadding(5, 5, 5, 5);
                tv.setText(String.valueOf(product.getQuantity().setScale(2)));
                row.addView(tv);

                tv = new TextView(getContext());
                tv.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT));
                tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
                tv.setPadding(5, 5, 5, 5);
                tv.setText(String.valueOf(product.getPrice().setScale(2)));
                row.addView(tv);

                tv = new TextView(getContext());
                tv.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT));
                tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
                tv.setPadding(5, 5, 5, 5);
                tv.setText(String.valueOf(product.getTotal().setScale(2)));
                row.addView(tv);

                _productsTblLayout.addView(row);
            }
        }
    }

}

