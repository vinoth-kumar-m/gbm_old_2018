package com.gbm.vo;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Created by Sri on 9/6/2017.
 */

public class SettingsVO implements Serializable {

    private long id;
    private String invoiceNo;
    private String bookingNo;

    public SettingsVO() {

    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getInvoiceNo() {
        return invoiceNo;
    }

    public void setInvoiceNo(String invoiceNo) {
        this.invoiceNo = invoiceNo;
    }

    public String getBookingNo() {
        return bookingNo;
    }

    public void setBookingNo(String bookingNo) {
        this.bookingNo = bookingNo;
    }
}
